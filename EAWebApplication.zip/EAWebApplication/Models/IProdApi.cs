﻿namespace EAWebApplication.Models
{
    //public interface IProdApi
    //{
    //}

    //public List<EA_API.EA_ProductsInMemory> Products { get; }
}

